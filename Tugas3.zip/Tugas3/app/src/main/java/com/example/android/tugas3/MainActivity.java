package com.example.android.tugas3;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView img = findViewById(R.id.img);
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.fabiola_s1_cropped);

        Bitmap bitmapBW = bitmap.copy(Bitmap.Config.ARGB_8888, true);

        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        for(int i=0; i<height; i++) //create grayscale image
        {
            for(int j=0; j<width; j++)
            {
                int pixel = bitmap.getPixel(j,i);
                int redValue = Color.red(pixel);
                int blueValue = Color.blue(pixel);
                int greenValue = Color.green(pixel);
                int bwValue = (redValue+blueValue+greenValue)/3;

                int currentBWColor = 0xFF000000 | (bwValue<<16 | bwValue<<8 | bwValue);
                bitmapBW.setPixel(j,i,currentBWColor);
            }
        }
        img.setImageBitmap(bitmapBW);

        Bitmap bitmapAfterBW = bitmapBW.copy(Bitmap.Config.ARGB_8888, true);
        for(int i=0; i<height-1; i++) //convolution
        {
            for(int j=0; j<width-1; j++)
            {

                int pixel = bitmap.getPixel(j,i);
                int redValue = Color.red(pixel);
                int blueValue = Color.blue(pixel);
                int greenValue = Color.green(pixel);
                int bwValue = (redValue+blueValue+greenValue)/3;
                int bwAvgValue;

                if(i==0){
                    if(j==0){ //pojok kiri atas
                        bwAvgValue = bwValue;
                    }
                    else if(j==width){ //pojok kanan atas
                        bwAvgValue = bwValue;
                    }
                    else { //tepi atas
                        int pixelL = bitmap.getPixel(j-1,i);
                        int redValueL = Color.red(pixelL);
                        int blueValueL = Color.blue(pixelL);
                        int greenValueL = Color.green(pixelL);
                        int bwValueL = (redValueL+blueValueL+greenValueL)/3;

                        int pixelR = bitmap.getPixel(j+1,i);
                        int redValueR = Color.red(pixelR);
                        int blueValueR = Color.blue(pixelR);
                        int greenValueR = Color.green(pixelR);
                        int bwValueR = (redValueR+blueValueR+greenValueR)/3;

                        bwAvgValue = (bwValueL+bwValue+bwValueR)/3;
                    }
                }
                else if(i==height){
                    if(j==0){ //pojok kiri bawah
                        bwAvgValue = bwValue;
                    }
                    else if(j==width){ //pojok kanan bawah
                        bwAvgValue = bwValue;
                    }
                    else { //tepi bawah
                        int pixelL = bitmap.getPixel(j-1,i);
                        int redValueL = Color.red(pixelL);
                        int blueValueL = Color.blue(pixelL);
                        int greenValueL = Color.green(pixelL);
                        int bwValueL = (redValueL+blueValueL+greenValueL)/3;

                        int pixelR = bitmap.getPixel(j+1,i);
                        int redValueR = Color.red(pixelR);
                        int blueValueR = Color.blue(pixelR);
                        int greenValueR = Color.green(pixelR);
                        int bwValueR = (redValueR+blueValueR+greenValueR)/3;

                        bwAvgValue = (bwValueL+bwValue+bwValueR)/3;
                    }
                }
                else{
                    if(j==0){ //tepi kiri
                        int pixelT = bitmap.getPixel(j,i-1);
                        int redValueT = Color.red(pixelT);
                        int blueValueT = Color.blue(pixelT);
                        int greenValueT = Color.green(pixelT);
                        int bwValueT = (redValueT+blueValueT+greenValueT)/3;

                        int pixelB = bitmap.getPixel(j,i+1);
                        int redValueB = Color.red(pixelB);
                        int blueValueB = Color.blue(pixelB);
                        int greenValueB = Color.green(pixelB);
                        int bwValueB = (redValueB+blueValueB+greenValueB)/3;

                        bwAvgValue = (bwValueT+bwValue+bwValueB)/3;
                    }
                    else if(j==width){ //tepi kanan
                        int pixelT = bitmap.getPixel(j,i-1);
                        int redValueT = Color.red(pixelT);
                        int blueValueT = Color.blue(pixelT);
                        int greenValueT = Color.green(pixelT);
                        int bwValueT = (redValueT+blueValueT+greenValueT)/3;

                        int pixelB = bitmap.getPixel(j,i+1);
                        int redValueB = Color.red(pixelB);
                        int blueValueB = Color.blue(pixelB);
                        int greenValueB = Color.green(pixelB);
                        int bwValueB = (redValueB+blueValueB+greenValueB)/3;

                        bwAvgValue = (bwValueT+bwValue+bwValueB)/3;
                    }
                    else { //bukan tepi
                        int pixelTL = bitmap.getPixel(j-1,i-1);
                        int redValueTL = Color.red(pixelTL);
                        int blueValueTL = Color.blue(pixelTL);
                        int greenValueTL = Color.green(pixelTL);
                        int bwValueTL = (redValueTL+blueValueTL+greenValueTL)/3;

                        int pixelT = bitmap.getPixel(j,i-1);
                        int redValueT = Color.red(pixelT);
                        int blueValueT = Color.blue(pixelT);
                        int greenValueT = Color.green(pixelT);
                        int bwValueT = (redValueT+blueValueT+greenValueT)/3;

                        int pixelTR = bitmap.getPixel(j+1,i-1);
                        int redValueTR = Color.red(pixelTR);
                        int blueValueTR = Color.blue(pixelTR);
                        int greenValueTR = Color.green(pixelTR);
                        int bwValueTR = (redValueTR+blueValueTR+greenValueTR)/3;

                        int pixelL = bitmap.getPixel(j-1,i);
                        int redValueL = Color.red(pixelL);
                        int blueValueL = Color.blue(pixelL);
                        int greenValueL = Color.green(pixelL);
                        int bwValueL = (redValueL+blueValueL+greenValueL)/3;

                        int pixelR = bitmap.getPixel(j+1,i);
                        int redValueR = Color.red(pixelR);
                        int blueValueR = Color.blue(pixelR);
                        int greenValueR = Color.green(pixelR);
                        int bwValueR = (redValueR+blueValueR+greenValueR)/3;

                        int pixelBL = bitmap.getPixel(j-1,i+1);
                        int redValueBL = Color.red(pixelBL);
                        int blueValueBL = Color.blue(pixelBL);
                        int greenValueBL = Color.green(pixelBL);
                        int bwValueBL = (redValueBL+blueValueBL+greenValueBL)/3;

                        int pixelB = bitmap.getPixel(j,i+1);
                        int redValueB = Color.red(pixelB);
                        int blueValueB = Color.blue(pixelB);
                        int greenValueB = Color.green(pixelB);
                        int bwValueB = (redValueB+blueValueB+greenValueB)/3;

                        int pixelBR = bitmap.getPixel(j+1,i+1);
                        int redValueBR = Color.red(pixelBR);
                        int blueValueBR = Color.blue(pixelBR);
                        int greenValueBR = Color.green(pixelBR);
                        int bwValueBR = (redValueBR+blueValueBR+greenValueBR)/3;

                        bwAvgValue = (bwValueTL + bwValueT + bwValueTR + bwValueL + bwValue + bwValueR + bwValueBL + bwValueB + bwValueBR)/9;
                    }
                }

                int currentBWColor = 0xFF000000 | (bwAvgValue<<16 | bwAvgValue<<8 | bwAvgValue);
                bitmapAfterBW.setPixel(j,i,currentBWColor);
            }
        }

        ImageView img2 = findViewById(R.id.img2);
        img2.setImageBitmap(bitmapAfterBW);
    }
}
