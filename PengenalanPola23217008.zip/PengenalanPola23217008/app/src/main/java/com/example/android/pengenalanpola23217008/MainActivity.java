package com.example.android.pengenalanpola23217008;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Menu and Welcome Message
        setContentView(R.layout.activity_main);

        // Find the View that shows the Tugas 1
        TextView tugas1 = (TextView) findViewById(R.id.tugas1);

        // Set a click listener on that View
        tugas1.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers View is clicked on.
            @Override
            public void onClick(View view) {
                Intent tugas1Intent = new Intent(MainActivity.this, Tugas1.class);
                startActivity(tugas1Intent);
            }
        });

        // Find the View that shows the Tugas 2
        TextView tugas2 = (TextView) findViewById(R.id.tugas2);

        // Set a click listener on that View
        tugas2.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers View is clicked on.
            @Override
            public void onClick(View view) {
                Intent tugas2Intent = new Intent(MainActivity.this, Tugas2.class);
                startActivity(tugas2Intent);
            }
        });

        // Find the View that shows the Tugas 2b
        TextView tugas2b = (TextView) findViewById(R.id.tugas2b);

        // Set a click listener on that View
        tugas2b.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers View is clicked on.
            @Override
            public void onClick(View view) {
                Intent tugas2bIntent = new Intent(MainActivity.this, Tugas2b.class);
                startActivity(tugas2bIntent);
            }
        });

        // Find the View that shows the Tugas 3a
        TextView tugas3a = (TextView) findViewById(R.id.tugas3a);

        // Set a click listener on that View
        tugas3a.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers View is clicked on.
            @Override
            public void onClick(View view) {
                Intent tugas3aIntent = new Intent(MainActivity.this, Tugas3a.class);
                startActivity(tugas3aIntent);
            }
        });

        // Find the View that shows the Tugas 3b
        TextView tugas3b = (TextView) findViewById(R.id.tugas3b);

        // Set a click listener on that View
        tugas3b.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers View is clicked on.
            @Override
            public void onClick(View view) {
                Intent tugas3bIntent = new Intent(MainActivity.this, Tugas3b.class);
                startActivity(tugas3bIntent);
            }
        });
    }
}
